# Custom Tabs Navigation Callbacks Demo

This demo shows how to launch a Custom Tab and receive navigation callbacks.

Information about navigations the user performs inside the Custom Tab will be
reported to the Android log and displayed on the demo launch screen.
This information will not contain URLs, but will be useful to collect
performance statistics.
