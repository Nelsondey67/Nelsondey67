# Custom Tabs Session Demo

This demo shows how to launch a Custom Tab and subsequently trigger a navigation
in that existing Custom Tab.

Five seconds after the use launches a Custom Tab with this demo, it will
navigate to a different page.  In practice, you could perform this action as the
result of the user clicking on a custom action button or secondary toolbar
button you provide (for example, as a "Home" button).
