# Custom Tabs Example App

This demo creates an Android App that can open custom tabs.
The app will be called "Custom Tabs Demos" and can launch any website.
