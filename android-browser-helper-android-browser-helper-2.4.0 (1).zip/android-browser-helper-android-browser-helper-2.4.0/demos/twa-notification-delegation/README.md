# Trusted Web Activity / Notification Delegation Demo

This demo application shows how a developer can override the notification prompt using native code
and take advantage of native Android notification features. In this example we use a custom
notification sound.

The relevant code for this example lives inside NotificationDelegationService.
 