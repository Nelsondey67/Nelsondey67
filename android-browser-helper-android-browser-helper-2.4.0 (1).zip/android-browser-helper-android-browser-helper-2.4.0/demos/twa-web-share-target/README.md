# TWA Web Share Target Demo

This demo creates an Android App that will start up and launch a TWA that uses Web Share Target.
