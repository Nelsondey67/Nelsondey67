# Trusted Web Activity / Screen Orientation Demo

This demo application shows how a developer can set the orientation in web manifest json file.

The relevant code for this example lives inside twa-orientation.
 