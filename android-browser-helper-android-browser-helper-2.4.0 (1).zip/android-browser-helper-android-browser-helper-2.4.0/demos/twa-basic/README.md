# TWA Basic

This demo creates an Android App that will start up and launch a TWA.
The app will be called "Basic TWA" and will launch `https://airhorner.com`.

This demo contains no Java/Kotlin code and just wires together and configures components already
existing in `androidx.browser` and `android-browser-helper`.
It is very similar to a project output from
[svgomg-twa](https://github.com/GoogleChromeLabs/svgomg-twa).

This demo exists primarily to make it easier for `android-browser-helper` developers to try out
their changes.