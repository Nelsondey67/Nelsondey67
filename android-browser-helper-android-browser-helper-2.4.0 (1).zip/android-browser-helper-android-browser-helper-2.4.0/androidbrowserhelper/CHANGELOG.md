## 1.1.0 (2020-01-22)

* [#53](https://github.com/GoogleChrome/android-browser-helper/pull/53) Provide an Intent to the 
  browser to focus the TWA. #53 ([@PEConn](https://github.com/PEConn))
  
## 1.0.0 (2020-01-08)

* android-browser-helper is stable :rocket:
* Uses androidx.browser.1.2.0
* Added Dark Mode Support for the Navigation bar and Status bar